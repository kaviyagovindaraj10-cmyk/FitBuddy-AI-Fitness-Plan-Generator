# FitBuddy – AI Fitness Plan Generator

Project organized into 8 phases:

1. 01 Brainstorming And Ideation
2. 02 Requirement Analysis
3. 03 Project Design
4. 04 Project Planning
5. 05 Project Development
6. 06 Project Testing
7. 07 Project Documentation
8. 08 Project Demonstration
